/* Copyright 2015-2017 Jack Humbert
 *
 * This program is free software: you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation, either version 2 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program.  If not, see <http://www.gnu.org/licenses/>.
 */

#include QMK_KEYBOARD_H
//  #define RGB_TIMEOUT 5
//#include "ws2812.h"
#include "muse.h"
#include "preonic.h"


#define BASIC_MIDI
#define MIDI_ADVANCED

//#include "rgblight_list.h"
//#define RGBLIGHT_IDLE_TIMEOUT 1
//#define RGB_CORAL        0xFF, 0x7C, 0x4D
//#define RGB_AZURE        0x99, 0xf5, 0xFF

//#define _RSHIFT RSFT_T(KC_SLSH)
#define _TEMP TD(_TEMPS)

enum preonic_layers {
  _QWERTY,
  _Q_PI,
  _LOWER,
  _RAISE,
  _ADJUST,
    _ORCA
};



enum preonic_keycodes {
  QWERTY = SAFE_RANGE,

  LOWER,
  RAISE,
  Q_PI,
  //BACKLIT,

  _ALG_1, //algorithm 1 - orca loading
  _ALG_2, //algorithm 2 - orca loading
  _ALG_3, //algorithm 3 - orca loading
  _ALG_4, //algorithm 4 - orca loading
  _ALG_5, //algorithm 3 - orca loading
  _ALG_6, //algorithm 4 - orca loading    // add disturbing algorithms and graphic B,N,M
  _ALG_7,// under 0

  _BUCH1,
  _BUCH2,  // Buchla patches
  _BUCH3,
  _BUCH4,

  _PATCH1,   // BUCHLA PATCH LOAD CHANNEL 16 (15 IN ORCA) PATCH 1
  _PATCH2,   //
  _PATCH3,
  _PATCH4,
  _PATCH5,
  _PATCH6,
  _PATCH7,
  _PATCH8,
  _PATCH9,
  _PATCH10,
  _PATCH11,
  _PATCH12,

  _SKIP, // SKIP ORCA FRAMES
  _REWIND,  // REWIND
  _TIMEZERO,  // GO TO FIRST FRAME
  _UNDO,    // CTRL + Z
  _REDO,  // CTRL + SHIFT + Z

  _GLITCH1,  ///  distrupters
  _GLITCH2,
  _GLITCH3,



  _GLOBAL, // global settings load          // add tempo change 300, 160, 80 apm and bpm, J, K, L or in [ ] i \ single double tripple tap
  _WHIPE, // whipe screen
  _MUTEK, // whipe one cell out of 6
  _PIX1, //pixel possition 1 - for  orca loading
  _PIX2, //pixel possition 2 - orca loading
  _PIX3, //pixel possition 3 - for  orca loading
  _PIX4, //pixel possition 4 - orca loading
  _PIX5, //pixel possition 5 - for  orca loading
  _PIX6, //pixel possition 6 - orca loading
  //_MID1,  // midi prgr change 1
  TMP_1,  // three tempo options with tapdance on []
  TMP_2,
  TMP_3,
MY_MACRO1,
MY_MACRO2,

  };

  enum tap_dance{
  SINGLE_TAP = 1,
  SINGLE_HOLD,
  DOUBLE_TAP,
  DOUBLE_HOLD,
  TRIPLE_TAP,
  TRIPLE_HOLD,
  QUAD_TAP,
  QUAD_HOLD,


  };

  //Tap dance enums
  enum {
  _TEMPS = 0
  };

  enum combos {
  BSP_PENT
  };

  //user_config_t;

  //void matrix_init_kb(void);


  //user_config_t user_config;

   static int alttap_state = 0;

  //tap dance
  int cur_dance (qk_tap_dance_state_t *state);

  //1. tap dance alt
   void alt_finished (qk_tap_dance_state_t *state, void *user_data);
   void alt_reset (qk_tap_dance_state_t *state, void *user_data);

  //2. tap dance reset layer 3
  void reset_finished (qk_tap_dance_state_t *state, void *user_data);
  void reset_reset (qk_tap_dance_state_t *state, void *user_data);




// rgb timeout
/*
  static uint16_t idle_timer = 0;
  static uint8_t halfmin_counter = 0;
  bool rgb_status = true;
  bool status = true;


*/

const uint16_t PROGMEM keymaps[][MATRIX_ROWS][MATRIX_COLS] = {

/* Qwerty
 * ,-----------------------------------------------------------------------------------.
 * |   `  |   1  |   2  |   3  |   4  |   5  |   6  |   7  |   8  |   9  |   0  | Bksp |
 * |------+------+------+------+------+------+------+------+------+------+------+------|
 * | Tab  |   Q  |   W  |   E  |   R  |   T  |   Y  |   U  |   I  |   O  |   P  |   ?
 * |------+------+------+------+------+-------------+------+------+------+------+------|
 * | Esc  |   A  |   S  |   D  |   F  |   G  |   H  |   J  |   K  |   L  |   ;  |Enter |
 * |------+------+------+------+------+------|------+------+------+------+------+------|
 * | Shift|   Z  |   X  |   C  |   V  |   B  |   N  |   M  |   ,  |   .  |   Up |
 * |------+------+------+------+------+------+------+------+------+------+------+------|
 * | Brite| Alt | Ctrl  | GUI  |Lower |    Space    |Raise |      | Left | Down |Right |
 * `-----------------------------------------------------------------------------------'
 */
[_QWERTY] = LAYOUT_preonic_grid( \
  KC_ESC,  KC_1,    KC_2,    KC_3,    KC_4,    KC_5,    KC_6,    KC_7,    KC_8,    KC_9,    KC_0,   KC_SLSH, \
  KC_TAB,  KC_Q,    KC_W,    KC_E,    KC_R,    KC_T,    KC_Y,    KC_U,    KC_I,    KC_O,    KC_P,  KC_BSPC,  \
  KC_GRV,  KC_A,    KC_S,    KC_D,    KC_F,    KC_G,    KC_H,    KC_J,    KC_K,    KC_L,    KC_SCLN, KC_ENT,    \
  KC_LSFT, KC_Z,    KC_X,    KC_C,    KC_V,    KC_B,    KC_N,    KC_M,    KC_COMM, KC_DOT,  KC_UP,    KC_RSFT,  \
  MY_MACRO1, KC_LALT, KC_LCTL, KC_LGUI, LOWER,   KC_SPC,  KC_SPC,  RAISE,   KC_RGUI, KC_LEFT, KC_DOWN,   KC_RGHT  \
),


/* Qwerty on RaspPi Q_PI
 * ,-----------------------------------------------------------------------------------.
 * |   `  |   1  |   2  |   3  |   4  |   5  |   6  |   7  |   8  |   9  |   0  | Bksp |
 * |------+------+------+------+------+------+------+------+------+------+------+------|
 * | Tab  |   Q  |   W  |   E  |   R  |   T  |   Y  |   U  |   I  |   O  |   P  |   ?
 * |------+------+------+------+------+-------------+------+------+------+------+------|
 * | Esc  |   A  |   S  |   D  |   F  |   G  |   H  |   J  |   K  |   L  |   ;  |Enter |
 * |------+------+------+------+------+------|------+------+------+------+------+------|
 * | Shift|   Z  |   X  |   C  |   V  |   B  |   N  |   M  |   ,  |   .  |   Up |
 * |------+------+------+------+------+------+------+------+------+------+------+------|
 * | Brite|System| Alt  | Ctrl  |Lower |    Space    |Raise |      | Left | Down |Right |
 * `-----------------------------------------------------------------------------------'
 */
[_Q_PI] = LAYOUT_preonic_grid( \
  KC_ESC,  KC_1,    KC_2,    KC_3,    KC_4,    KC_5,    KC_6,    KC_7,    KC_8,    KC_9,    KC_0,   KC_SLSH, \
  KC_TAB,  KC_Q,    KC_W,    KC_E,    KC_R,    KC_T,    KC_Y,    KC_U,    KC_I,    KC_O,    KC_P,  KC_BSPC,  \
  KC_GRV,  KC_A,    KC_S,    KC_D,    KC_F,    KC_G,    KC_H,    KC_J,    KC_K,    KC_L,    KC_SCLN, KC_ENT,    \
  KC_LSFT, KC_Z,    KC_X,    KC_C,    KC_V,    KC_B,    KC_N,    KC_M,    KC_COMM, KC_DOT,  KC_UP,    KC_RSFT,  \
  MY_MACRO1, KC_LALT, KC_LGUI, KC_LCTL, LOWER,   KC_SPC,  KC_SPC,  RAISE,   KC_RCTL, KC_LEFT, KC_DOWN,   KC_RGHT  \
),


/* Lower  !!@45@444333
 * ,-----------------------------------------------------------------------------------.
 * |   ~  |   !  |   @  |   #  |   $  |   %  |   ^  |   &  |   *  |   _  |   +  | Bksp |
 * |------+------+------+------+------+-------------+------+------+------+------+------|
 * |   ~  |   !  |   @  |   #  |   $  |   %  |   ^  |   &  |   *  |   (  |   )  | Del  |
 * |------+------+------+------+------+-------------+------+------+------+------+------|
 * | Del  |  F1  |  F2  |  F3  |  F4  |  F5  |  F6  |   _  |   +  |   {  |   }  |  |   |
 * |------+------+------+------+------+------|------+------+------+------+------+------|
 * |      |  F7  |  F8  |  F9  |  F10 |  F11 |  F12 |ISO ~ |ISO | |      |      |      |
 * |------+------+------+------+------+------+------+------+------+------+------+------|
 * |      |      |      |      |      |             |      | Next | Vol- | Vol+ | Play |
 * `-----------------------------------------------------------------------------------'
 */
[_LOWER] = LAYOUT_preonic_grid( \
  KC_TILD,      KC_1,  KC_2,   KC_3, KC_4,  KC_5,   KC_6, KC_7, KC_8, KC_9, KC_0, KC_BSPC, \
  KC_TILD,      KC_EXLM,  KC_AT,   KC_HASH, KC_DLR,  KC_PERC,   KC_CIRC, KC_AMPR, KC_ASTR, KC_LPRN, KC_RPRN, KC_DEL,  \
  KC_DEL,       KC_F1,      KC_F2,   KC_F3,   KC_F4,   KC_F5,   KC_F6,   KC_UNDS, KC_PLUS, KC_LCBR, KC_RCBR, KC_PIPE, \
  _______,       KC_F7,   KC_F8,    KC_F9,   KC_F10,    KC_F11,  KC_F12, _______, _______,  KC_HOME,KC_END, _______, \
  _______,      _______,   _______, _______, _______, _______,  _______, _______, KC_MNXT, KC_VOLD, KC_VOLU, KC_MPLY \
),

/* Raise
 * ,-----------------------------------------------------------------------------------.
 * |   `  |   1  |   2  |   3  |   4  |   5  |   6  |   7  |   8  |   -  |   =  | Bksp |
 * |------+------+------+------+------+------+------+------+------+------+------+------|
 * |   `  |   1  |   2  |   3  |   4  |   5  |   6  |   7  |   8  |   9  |   0  | Del  |
 * |------+------+------+------+------+-------------+------+------+------+------+------|
 * | Del  |  F1  |  F2  |  F3  |  F4  |  F5  |  F6  |   -  |   =  |   [  |   ]  |  \   |
 * |------+------+------+------+------+------|------+------+------+------+------+------|
 * |      |  F7  |  F8  |  F9  |  F10 |  F11 |  F12 |ISO # |ISO / |      |      |      |
 * |------+------+------+------+------+------+------+------+------+------+------+------|
 * |      |      |      |      |      |             |      | Next | Vol- | Vol+ | Play |
 * `-----------------------------------------------------------------------------------'
 */
[_RAISE] = LAYOUT_preonic_grid( \
  KC_ESC,  KC_BRID,   KC_BRIU,    KC_F1,    KC_F2,    KC_5,    KC_6,    KC_7,    KC_UNDS,    KC_MINS,    KC_EQUAL,  KC_SLSH, \
  KC_TAB,  KC_1,    KC_2,    KC_3,    KC_4,    KC_5,    KC_6,    KC_7,    KC_8,    KC_LBRC,    KC_RBRC,    KC_DEL,  \
  KC_GRV,  KC_F1,   KC_F2,   KC_F3,   KC_F4,   KC_F5,   KC_F6,   KC_MINS, KC_EQL,  _______, KC_QUOTE, KC_BSLS, \
  _______, KC_F7,   KC_F8,   KC_F9,   KC_F10,  KC_F11,  KC_F12,  KC_NUHS, KC_NUBS, _______, KC_HOME, _______, \
  _______, _______, _______, _______, _______, _______, _______, _______, KC_MNXT, KC_PGDN, KC_END, KC_PGUP  \
),

/* Adjust (Lower + Raise)
 * ,-----------------------------------------------------------------------------------.
 * |  F1  |  F2  |  F3  |  F4  |  F5  |  F6  |  F7  |  F8  |  F9  |  F10 |  F11 |  F12 |
 * |------+------+------+------+------+------+------+------+------+------+------+------|
 * |RGB_TOG|Reset|      |      |Q_PI  |Qwerty|      |      |      |      |      |  Del |
 * |------+------+------+------+------+-------------+------+------+------+------+------|
 * |      |      |      |Aud on|AudOff|AGnorm|AGswap|      |      |      |      |      |
 * |------+------+------+------+------+------|------+------+------+------+------+------|
 * |      |Voice-|Voice+|Mus on|MusOff|MidiOn|MidOff|      |      |      |      |      |
 * |------+------+------+------+------+------+------+------+------+------+------+------|
 * |      |      |      |      |      |             |      |      |      |      |      |
 * `-----------------------------------------------------------------------------------'
 */

[_ADJUST] = LAYOUT_preonic_grid( \
              KC_F1,   KC_F2, KC_F3,  KC_F4,   KC_F5,   KC_F6,   KC_F7,   KC_F8,   KC_F9,   KC_F10,  KC_F11,  KC_F12,  \
            RGB_TOG, RESET, DEBUG, _______,   Q_PI  ,_______, QWERTY, TERM_ON, TERM_OFF,_______, _______, KC_DEL,  \
  RGB_MODE_FORWARD,_______,MU_MOD,  AU_ON,   AU_OFF,  AG_NORM, AG_SWAP, _______,  _______,_______ ,  _______, _______, \
          RGB_MOD, MUV_DE, MUV_IN,  MU_ON,   MU_OFF,  MI_ON,   MI_OFF,  MI_E_3, MI_D_2, KC_MS_BTN1, KC_MS_UP, KC_MS_BTN2, \
        _______, _______, _______, _______, _______, _______, _______, _______, _______, KC_MS_LEFT, KC_MS_DOWN, KC_MS_RIGHT  \
),
/* ORCA

 * ,-----------------------------------------------------------------------------------.
 * |   `  |   1  |   2  |   3  |   4  |   5  |   6  |   7  |   8  |   9  |   0  | Bksp |
 * |------+------+------+------+------+------+------+------+------+------+------+------|
 * | Tab  |   Q  |   W  |   E  |   R  |   T  |   Y  |   U  |   I  |   O  |   P  |   ?
 * |------+------+------+------+------+-------------+------+------+------+------+------|
 * | Esc  |   A  |   S  |   D  |   F  |   G  |   H  |   J  |   K  |   L  |   ;  |Enter |
 * |------+------+------+------+------+------|------+------+------+------+------+------|
 * | Shift|   Z  |   X  |   C  |   V  |   B  |   N  |   M  |   ,  |   .  |   Up |
 * |------+------+------+------+------+------+------+------+------+------+------+------|
 * | Brite| Ctrl | Alt  | GUI  |Lower |    Space    |Raise |      | Left | Down |Right |
 * `-----------------------------------------------------------------------------------'
 */
////_WHIPE   _MUTEK,RCTL(KC_MINS)

[_ORCA] = LAYOUT_preonic_grid( \

	KC_ESC,    _PATCH1,              _PATCH2,       _PATCH3,      _PATCH4,    _PATCH5,      _PATCH6,  _PATCH7,      _PATCH8, _PATCH9,     RCTL(KC_EQUAL),  KC_SLSH, \
  _PATCH10,    _PATCH11,	          RCTL(KC_UP),    _PATCH12,         _PIX1,    _PIX2,       _PIX3,    _ALG_1,        _ALG_2,     _ALG_3,    _ALG_4,      KC_BSPC,  \
	_TIMEZERO,     RCTL(KC_LEFT),    RCTL(KC_DOWN), RCTL(KC_RGHT), _PIX4,    _PIX5,      _PIX6,      _BUCH1,        _BUCH2,      _BUCH3,     _BUCH4,      KC_ENT,  \
KC_LSFT,     _UNDO,            KC_X,          KC_C,           KC_V,     _GLOBAL,     TD(_TEMPS),        _GLITCH1,       _GLITCH2,    _GLITCH3,     KC_UP,    _SKIP,  \
MY_MACRO2,    _REWIND,        _REDO,     KC_LCTL,       LOWER,     KC_SPC,      KC_SPC,      RAISE,    KC_RCTL,     KC_LEFT,      KC_DOWN,    KC_RGHT  \
)
/////////////////  orca


};



// sounds  ////

#ifdef AUDIO_ENABLE
float tone_startup[][2] = {
  {NOTE_B5, 20},
  {NOTE_B6, 8},
  {NOTE_DS6, 20},
  {NOTE_B6, 8}
};

float tone_qwerty[][2]     = SONG(QWERTY_SOUND);

float tone_colemak[][2]     = SONG(COLEMAK_SOUND);

//float tone_numpad[][2]     = SONG(NUMPAD_SOUND);

float tone_goodbye[][2] = SONG(GOODBYE_SOUND);

float music_scale[][2]     = SONG(MUSIC_SCALE_SOUND);

#endif


/////   songs   /////


void matrix_init_user(void) {
    #ifdef AUDIO_ENABLE
        startup_user();
    #endif
}

#ifdef AUDIO_ENABLE

void startup_user()
{
//    _delay_ms(50); // gets rid of tick
    PLAY_SONG(tone_startup);

        rgblight_enable_noeeprom();
      //  rgblight_mode_noeeprom(1);
        rgblight_sethsv_noeeprom (190,  255, 190);
}

void shutdown_user()
{
    PLAY_SONG(tone_goodbye);
  //  _delay_ms(150);
    stop_all_notes();
}

void music_on_user(void)
{
    music_scale_user();
}


void music_scale_user(void)
{
    PLAY_SONG(music_scale);

}
#endif



// chords to test midi





//backlight RGB timeout

/*

void matrix_scan_kb(void) {
  // Looping keyboard code goes here
  // This runs every cycle (a lot)
  matrix_scan_user();

  if (idle_timer == 0)
  {
    idle_timer = timer_read();
  }

  if(timer_elapsed(idle_timer) > 30000){
    halfmin_counter++;
    idle_timer = timer_read();
  }

  if(halfmin_counter >= RGB_TIMEOUT * 2){
    status = false;
  //  rgb_status = is_rgb_enabled();
    rgblight_disable();
  //  rgblight_mode_noeeprom(2); rgblight_sethsv_noeeprom(200,250,100);
    halfmin_counter = 0;
  }
};

void eeconfig_init_user(void) {  // EEPROM is getting reset!
  user_config.rgb_layer_change = true; // We want this enabled by default
  eeconfig_update_user(user_config.raw); // Write default value to EEPROM now

  // use the non noeeprom versions, to write these values to EEPROM too
  rgblight_enable(); // Enable RGB by default
  rgblight_sethsv_noeeprom (190,  255, 190);
  // rgblight_sethsv(146,  221, 154);  // Set it to TURQUOISE by default
}

*/
/////




bool process_record_user(uint16_t keycode, keyrecord_t *record) {
  switch (keycode) {
        case QWERTY:
          if (record->event.pressed) {

            PLAY_SONG(tone_qwerty);
            set_single_persistent_default_layer(_QWERTY);

          }
          return false;
          break;


          case Q_PI:
            if (record->event.pressed) {

              PLAY_SONG(tone_colemak);
              set_single_persistent_default_layer(_Q_PI);

            }
            return false;
            break;



        case LOWER:
          if (record->event.pressed) {
            layer_on(_LOWER);
            update_tri_layer(_LOWER, _RAISE, _ADJUST);
          } else {
            layer_off(_LOWER);
            update_tri_layer(_LOWER, _RAISE, _ADJUST);
          }
          return false;
          break;


        case RAISE:
          if (record->event.pressed) {
            layer_on(_RAISE);
            update_tri_layer(_LOWER, _RAISE, _ADJUST);
          } else {
            layer_off(_RAISE);
            update_tri_layer(_LOWER, _RAISE, _ADJUST);
          }
          return false;
          break;
/*
        case BACKLIT:   no backlit in preonic v3 !!

          if (record->event.pressed) {
            register_code(KC_RSFT);
            #ifdef BACKLIGHT_ENABLE
              backlight_step();
            #endif
            #ifdef __AVR__
            PORTE &= ~(1<<6);
            #endif
          } else {
            unregister_code(KC_RSFT);
            #ifdef __AVR__
            PORTE |= (1<<6);
            #endif
          }
          return false;
          break;


*/

/////// / /     macro shift layer change


              case MY_MACRO1:      ////  in QWERTY
              if (record->event.pressed && get_mods() & MOD_MASK_SHIFT) {

                  set_single_persistent_default_layer(_ORCA);
                //  rgblight_mode_noeeprom(1);
                  rgblight_sethsv(128,  255, 150);
                    PLAY_SONG(tone_goodbye);

              }
              return false;
              break;

              case MY_MACRO2:    ///////  in FKEYS
              if (record->event.pressed && get_mods() & MOD_MASK_SHIFT) {

                set_single_persistent_default_layer(_Q_PI);
              //  rgblight_mode_noeeprom(1);
                rgblight_sethsv(28,  255, 200);
                PLAY_SONG(tone_colemak);

              }
              return false;
              break;



          ///// ALGORITHMS coded as keystrokes/ buttons  need to be names algo1,2,3 in ORCA


              case _ALG_1:
                  if (record->event.pressed) {  //   make CMD as CMD + K     HERE start with CMD + K to go to CMD mode in orca       midi midi_send_programchange(&midi_device, midi_config.channel, <1>);
                      SEND_STRING(SS_LCTRL("j")"algo1;");
                  }
                  return false; break;


              case _ALG_2:
                  if (record->event.pressed) {
                      SEND_STRING(SS_LCTRL("j")"algo2;");
                  }
                  return false; break;
                case _ALG_3:
                    if (record->event.pressed) {  //   make CMD as CMD + K     HERE start with CMD + K to go to CMD mode in orca       midi midi_send_programchange(&midi_device, midi_config.channel, <1>);
                        SEND_STRING(SS_LCTRL("j")"algo3;");
                    }
                    return false; break;
                case _ALG_4:
                    if (record->event.pressed) {
                        SEND_STRING(SS_LCTRL("j")"algo4;");
                    }
                    return false; break;

                    case _ALG_5:
                        if (record->event.pressed) {
                            SEND_STRING(SS_LCTRL("j")"algo5;" SS_TAP(X_ENTER));
                        }
                        return false; break;

                        case _ALG_6:
                            if (record->event.pressed) {
                                SEND_STRING(SS_LCTRL("j")"algo6;" SS_TAP(X_ENTER));
                            }
                            return false; break;


                            case _ALG_7:
                                if (record->event.pressed) {
                                    SEND_STRING(SS_LCTRL("j")"algo7;" SS_TAP(X_ENTER));
                                }
                                return false; break;


                                case _UNDO:
                                    if (record->event.pressed) {
                                        SEND_STRING(SS_LCTRL("z"));
                                    }
                                    return false; break;

                                    case _REDO:
                                        if (record->event.pressed) {
                                            SEND_STRING(SS_LCTRL(SS_LSFT("z")));
                                        }
                                        return false; break;



                                    case _PATCH1:
                                        if (record->event.pressed) {
                                            SEND_STRING(SS_LCTRL("k") "pg:15;;;0" SS_TAP(X_ENTER));
                                        }
                                        return false; break;

                                        case _PATCH2:
                                            if (record->event.pressed) {
                                                SEND_STRING(SS_LCTRL("k") "pg:15;;;1" SS_TAP(X_ENTER));
                                            }
                                            return false; break;

                                            case _PATCH3:
                                                if (record->event.pressed) {
                                                    SEND_STRING(SS_LCTRL("k") "pg:15;;;2" SS_TAP(X_ENTER));
                                                }
                                                return false; break;


                                                case _PATCH4:
                                                    if (record->event.pressed) {
                                                        SEND_STRING(SS_LCTRL("k") "pg:15;;;3" SS_TAP(X_ENTER));
                                                    }
                                                    return false; break;


                                                    case _PATCH5:
                                                        if (record->event.pressed) {
                                                            SEND_STRING(SS_LCTRL("k") "pg:15;;;4" SS_TAP(X_ENTER));
                                                        }
                                                        return false; break;

                                                        case _PATCH6:
                                                            if (record->event.pressed) {
                                                                SEND_STRING(SS_LCTRL("k") "pg:15;;;5" SS_TAP(X_ENTER));
                                                            }
                                                            return false; break;


                                                            case _PATCH7:
                                                                if (record->event.pressed) {
                                                                    SEND_STRING(SS_LCTRL("k") "pg:15;;;6" SS_TAP(X_ENTER));
                                                                }
                                                                return false; break;

                                                                case _PATCH8:
                                                                    if (record->event.pressed) {
                                                                        SEND_STRING(SS_LCTRL("k") "pg:15;;;7" SS_TAP(X_ENTER));
                                                                    }
                                                                    return false; break;

                                                                    case _PATCH9:
                                                                        if (record->event.pressed) {
                                                                            SEND_STRING(SS_LCTRL("k") "pg:15;;;8" SS_TAP(X_ENTER));
                                                                        }
                                                                        return false; break;


                                                                        case _PATCH10:
                                                                            if (record->event.pressed) {
                                                                                SEND_STRING(SS_LCTRL("k") "pg:15;;;9" SS_TAP(X_ENTER));
                                                                            }
                                                                            return false; break;



                                                                            case _PATCH11:
                                                                                if (record->event.pressed) {
                                                                                    SEND_STRING(SS_LCTRL("k") "pg:15;;;10" SS_TAP(X_ENTER));
                                                                                }
                                                                                return false; break;

                                                                                case _PATCH12:
                                                                                    if (record->event.pressed) {
                                                                                        SEND_STRING(SS_LCTRL("k") "pg:15;;;11" SS_TAP(X_ENTER));
                                                                                    }
                                                                                    return false; break;


                                              case _REWIND:
                                                      if (record->event.pressed) {
                                                      SEND_STRING(SS_LCTRL("k") "rewind:2" SS_TAP(X_ENTER));
                                                        }
                                                    return false; break;

                                                    case _SKIP:
                                                            if (record->event.pressed) {
                                                            SEND_STRING(SS_LCTRL("k") "skip:2" SS_TAP(X_ENTER));
                                                              }
                                                          return false; break;

                                                          case _TIMEZERO:
                                                                  if (record->event.pressed) {
                                                                  SEND_STRING(SS_LCTRL("k") "time:0" SS_TAP(X_ENTER));
                                                                    }
                                                                return false; break;






                                case _BUCH1:
                                    if (record->event.pressed) {
                                        SEND_STRING(SS_LCTRL("j")"buch1;" SS_TAP(X_ENTER));
                                    }
                                    return false; break;



                                                                  case _BUCH2:
                                                                    if (record->event.pressed) {
                                                                      SEND_STRING(SS_LCTRL("j")"buch2;" SS_TAP(X_ENTER));
                                                                      }
                                                                  return false; break;



                                                                                case _BUCH3:
                                                                                        if (record->event.pressed) {
                                                                                          SEND_STRING(SS_LCTRL("j")"buch3;" SS_TAP(X_ENTER));
                                                                                              }
                                                                                  return false; break;



                                                                                case _BUCH4:
                                                                                            if (record->event.pressed) {
                                                                                                SEND_STRING(SS_LCTRL("j")"buch4;" SS_TAP(X_ENTER));
                                                                                                      }
                                                                                  return false; break;









                                case _GLITCH1:
                                    if (record->event.pressed) {
                                        SEND_STRING(SS_LCTRL("j")"glitch1;" SS_TAP(X_ENTER));
                                    }
                                    return false; break;

                                    case _GLITCH2:
                                        if (record->event.pressed) {
                                            SEND_STRING(SS_LCTRL("j")"glitch2;" SS_TAP(X_ENTER));
                                        }
                                        return false; break;

                                        case _GLITCH3:
                                            if (record->event.pressed) {
                                                SEND_STRING(SS_LCTRL("j")"glitch3;" SS_TAP(X_ENTER));
                                            }
                                            return false; break;



                            case _GLOBAL:
                                if (record->event.pressed) {
                                    SEND_STRING(SS_LCTRL("j")"global;" SS_TAP(X_ENTER));
                                }
                                return false; break;



                    case _WHIPE:
                        if (record->event.pressed) {
                            SEND_STRING(SS_LCTRL("j")"whipe;" SS_TAP(X_ENTER));
                              PLAY_SONG(tone_colemak);
                        }
                        return false; break;

                        case _MUTEK:
                            if (record->event.pressed) {
                                SEND_STRING(SS_LCTRL("j")"mutek;" SS_TAP(X_ENTER));
                            }
                            return false; break;

                default:
                  return true; // Process all other keycodes normally


          /// Possitions in on the screen coded to keystrokes / buttons /////


                case _PIX1:
                    if (record->event.pressed) {
                        SEND_STRING(SS_LCTRL("k") "select:0;0;" SS_TAP(X_ENTER));
            //            PLAY_SONG(tone_qwerty);
                    }
                    return false; break;

                    case _PIX2:
                        if (record->event.pressed) {  //   HERE  possibly add ENTER at the END to go out of inject mode.
                            SEND_STRING(SS_LCTRL("k") "select:32;0;" SS_TAP(X_ENTER));
                        }
                        return false; break;

                        case _PIX3:
                            if (record->event.pressed) {  //   HERE  possibly add ENTER at the END to go out of inject mode.
                                SEND_STRING(SS_LCTRL("k") "select:64;0;" SS_TAP(X_ENTER));
                            }
                            return false; break;

                            case _PIX4:
                                if (record->event.pressed) {  //   HERE  possibly add ENTER at the END to go out of inject mode.
                                    SEND_STRING(SS_LCTRL("k") "select:0;16;" SS_TAP(X_ENTER));
                                }
                                return false; break;

                              case _PIX5:
                                 if (record->event.pressed) {  //   HERE  possibly add ENTER at the END to go out of inject mode.
                                    SEND_STRING(SS_LCTRL("k") "select:32;16;" SS_TAP(X_ENTER));
                                  }
                                    return false; break;

                                   case _PIX6:
                                  if (record->event.pressed) {  //   HERE  possibly add ENTER at the END to go out of inject mode.
                                    SEND_STRING(SS_LCTRL("k") "select:64;16;" SS_TAP(X_ENTER));
                                  }
                                 return false; break;

;

                               }

                             }



bool muse_mode = false;
uint8_t last_muse_note = 0;
uint16_t muse_counter = 0;
uint8_t muse_offset = 70;
uint16_t muse_tempo = 50;

void encoder_update_user(uint8_t index, bool clockwise) {
  if (muse_mode) {
    if (IS_LAYER_ON(_RAISE)) {
      if (clockwise) {
        muse_offset++;
      } else {
        muse_offset--;
      }
    } else {
      if (clockwise) {
        muse_tempo+=1;
      } else {
        muse_tempo-=1;
      }
    }
  } else {
    if (clockwise) {
      register_code(KC_PGDN);
      unregister_code(KC_PGDN);
    } else {
      register_code(KC_PGUP);
      unregister_code(KC_PGUP);
    }
  }
}

void dip_update(uint8_t index, bool active) {
  switch (index) {
    case 0:
      if (active) {
        layer_on(_ADJUST);
      } else {
        layer_off(_ADJUST);
      }
      break;
    case 1:
      if (active) {
        muse_mode = true;
      } else {
        muse_mode = false;
        #ifdef AUDIO_ENABLE
          stop_all_notes();
        #endif
      }
   }
}

void matrix_scan_user(void) {
  #ifdef AUDIO_ENABLE
    if (muse_mode) {
      if (muse_counter == 0) {
        uint8_t muse_note = muse_offset + SCALE[muse_clock_pulse()];
        if (muse_note != last_muse_note) {
          stop_note(compute_freq_for_midi_note(last_muse_note));
          play_note(compute_freq_for_midi_note(muse_note), 0xF);
          last_muse_note = muse_note;
        }
      }
      muse_counter = (muse_counter + 1) % muse_tempo;
    }
  #endif
}

bool music_mask_user(uint16_t keycode) {
  switch (keycode) {
    case RAISE:
    case LOWER:
      return false;
    default:
      return true;
  }
}






          ///////       ///////   /////////




int cur_dance (qk_tap_dance_state_t *state) {
  if (state->count == 1) {
    if (state->pressed) return SINGLE_HOLD;
     return SINGLE_TAP;
  }
  else if (state->count == 2) {
   if (state->pressed) return DOUBLE_HOLD;
     return DOUBLE_TAP;
  }
//else return 8;  // this paste below
//////
  else if (state->count == 3) {
    if (state->pressed)  return TRIPLE_HOLD;
     return TRIPLE_TAP;
  }

  else if (state->count == 4) {
    if (state->interrupted || !state->pressed)  return QUAD_TAP;
    else return QUAD_HOLD;
  }


  else return 8;

}

void alt_finished (qk_tap_dance_state_t *state, void *user_data) {
  alttap_state = cur_dance(state);
  switch (alttap_state) {
    // OSL
    case SINGLE_TAP: SEND_STRING(SS_LCTRL("k") "bpm:68" SS_TAP(X_ENTER)); break;
    // ALT
   case SINGLE_HOLD: register_code(KC_LALT); break;
    // DF
    case DOUBLE_TAP: SEND_STRING(SS_LCTRL("k") "bpm:110" SS_TAP(X_ENTER)); break;

      case TRIPLE_TAP: SEND_STRING(SS_LCTRL("k") "bpm:160" SS_TAP(X_ENTER)); break;

      case QUAD_TAP: SEND_STRING(SS_LCTRL("k") "bpm:300" SS_TAP(X_ENTER)); break;

    // ALT + OSL + KEY
//    case DOUBLE_HOLD: register_code(KC_LALT); set_oneshot_layer(_ORCA, ONESHOT_START); clear_oneshot_layer_state(ONESHOT_PRESSED); break;
    //Last case is for fast typing. Assuming your key is `f`:
    //For example, when typing the word `buffer`, and you want to make sure that you send `ff` and not `Esc`.
    //In order to type `ff` when typing fast, the next character will have to be hit within the `TAPPING_TERM`, which by default is 200ms.
  }
}

void alt_reset (qk_tap_dance_state_t *state, void *user_data) {
  switch (alttap_state) {
    case SINGLE_TAP: break;
    case SINGLE_HOLD: unregister_code(KC_LALT); break;
    case DOUBLE_TAP: break;
    case TRIPLE_TAP: break;
    case TRIPLE_HOLD: break;
    case DOUBLE_HOLD: unregister_code(KC_LALT); break;
case QUAD_TAP: break;
case QUAD_HOLD: break;

  }
  alttap_state = 0;
}

qk_tap_dance_action_t tap_dance_actions[] = {
  [_TEMPS]     = ACTION_TAP_DANCE_FN_ADVANCED(NULL,alt_finished, alt_reset)
};
